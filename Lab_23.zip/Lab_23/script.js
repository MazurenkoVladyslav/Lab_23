document.addEventListener('DOMContentLoaded', () => {
    const localStorageKey = 'productCards';
    const startButton = document.getElementById('startButton');
    const clearStorageButton = document.getElementById('clearStorageButton');
    const categoryFilter = document.getElementById('categoryFilter');
    const searchTerm = document.getElementById('searchTerm');
    const sortOrder = document.getElementById('sortOrder');
    const productList = document.getElementById('productList');

    async function fetchDataAndStore() {
        try {
            const response = await fetch('https://dummyjson.com/products?limit=100&skip=0');
            const data = await response.json();
            const products = data.products.map(product => ({
                title: product.title,
                description: product.description,
                category: product.category,
                price: product.price,
                date: new Date().toISOString().split('T')[0]
            }));
            localStorage.setItem(localStorageKey, JSON.stringify(products));
            console.log('Data fetched and stored in localStorage:', products);
            displayProducts(products);
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    }

    function displayProducts(filteredProducts) {
        productList.innerHTML = '';
        filteredProducts.forEach(product => {
            const card = document.createElement('div');
            card.className = 'product-card';
            card.innerHTML = `
                <h3>${product.title}</h3>
                <p>${product.description}</p>
                <p><strong>Категорія:</strong> ${product.category}</p>
                <p><strong>Ціна:</strong> ${product.price} грн</p>
                <p><strong>Дата додавання:</strong> ${product.date}</p>
            `;
            productList.appendChild(card);
        });
    }

    function filterAndSortProducts() {
        let products = JSON.parse(localStorage.getItem(localStorageKey)) || [];

        const category = categoryFilter.value;
        if (category) {
            products = products.filter(product => product.category === category);
        }

        const search = searchTerm.value.toLowerCase();
        if (search) {
            products = products.filter(product => product.title.toLowerCase().includes(search) || product.description.toLowerCase().includes(search));
        }

        const sort = sortOrder.value;
        products.sort((a, b) => {
            if (sort === 'priceAsc') return a.price - b.price;
            if (sort === 'priceDesc') return b.price - a.price;
            if (sort === 'newest') return new Date(b.date) - new Date(a.date);
            if (sort === 'oldest') return new Date(a.date) - new Date(b.date);
        });

        displayProducts(products);
    }

    function init() {
        const storedProducts = localStorage.getItem(localStorageKey);
        if (storedProducts) {
            displayProducts(JSON.parse(storedProducts));
        } else {
            startButton.style.display = 'block';
        }

        startButton.addEventListener('click', () => {
            fetchDataAndStore();
            startButton.style.display = 'none';
        });

        clearStorageButton.addEventListener('click', () => {
            localStorage.removeItem(localStorageKey);
            console.log('LocalStorage cleared');
            startButton.style.display = 'block';
            productList.innerHTML = '';
        });

        categoryFilter.addEventListener('change', filterAndSortProducts);
        searchTerm.addEventListener('input', filterAndSortProducts);
        sortOrder.addEventListener('change', filterAndSortProducts);
    }

    init();
});
